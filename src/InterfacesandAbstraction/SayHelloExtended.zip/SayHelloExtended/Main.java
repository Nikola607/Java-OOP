package SayHelloExtended;

public class Main {
}
